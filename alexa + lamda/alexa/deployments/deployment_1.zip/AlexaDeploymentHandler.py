from AlexaBaseHandler import AlexaBaseHandler
import random

def choose_joke():
        jokes = list()
        j1 = "My wife’s cooking is so bad we usually pray after our food."
        j2 = "My wife told me she needs more space. I said no problem and locked her out of the house."
        j3 = "What to give a man who’s got everything? A woman. She’ll tell him how everything works."
        j4 = "Of course I have a talent. I'm really good in bed. Sometimes I sleep more than 9 hours in one go."
        j5 = "According to my mirror I am pregnant. The father is Nutella."
        jokes.append(j1)
        jokes.append(j2)
        jokes.append(j3)
        jokes.append(j4)
        jokes.append(j5)
        return random.choice(jokes)


class AlexaDeploymentHandler(AlexaBaseHandler):
    """
    Sample concrete implementation of the AlexaBaseHandler to test the
    deployment scripts and process.
    All on_ handlers call the same test response changing the request type
    spoken.
    """

    def __init__(self):
        super(self.__class__, self).__init__()

    def choose_joke():
        jokes = list()
        j1 = "My wife’s cooking is so bad we usually pray after our food."
        j2 = "My wife told me she needs more space. I said no problem and locked her out of the house."
        j3 = "What to give a man who’s got everything? A woman. She’ll tell him how everything works."
        j4 = "Of course I have a talent. I'm really good in bed. Sometimes I sleep more than 9 hours in one go."
        j5 = "According to my mirror I am pregnant. The father is Nutella."
        jokes.append(j1)
        jokes.append(j2)
        jokes.append(j3)
        jokes.append(j4)
        jokes.append(j5)
        return random.choice(jokes)

    
    def _test_response(self, msg):
        session_attributes = {}
        card_title = "Test Response"
        card_output = "Test card output"
        ##speech_output = "response is {0}".format(msg)
        speech_output = msg
        # If the user either does not reply to the welcome message or says something
        # that is not understood, they will be prompted again with this text.
        reprompt_text = "Reprompt text for the Alexa Test Deployment"
        should_end_session = True

        speechlet = self._build_speechlet_response(card_title, card_output, speech_output, reprompt_text, should_end_session)

        return self._build_response(session_attributes, speechlet)

    def on_processing_error(self, event, context, exc):
        return self._test_response("on processing error")

    def on_launch(self, launch_request, session):
        return self._test_response("welcome")

    def on_session_started(self, session_started_request, session):
        return self._test_response("on session started")

    def on_intent(self, intent_request, session):
        value = intent_request['intent']['name']
        if value == "joke":
            val = choose_joke()
        elif value == "story"
            val = "hahahahaahaaahaaahaha. sorry am an idiot right"
        session_attributes = {}
        card_title = "Test Response"
        card_output = "Test card output"
        ##speech_output = "response is {0}".format(msg)
        speech_output = val
        # If the user either does not reply to the welcome message or says something
        # that is not understood, they will be prompted again with this text.
        reprompt_text = "Reprompt text for the Alexa Test Deployment"
        should_end_session = True

        speechlet = self._build_speechlet_response(card_title, card_output, speech_output, reprompt_text, should_end_session)
        return self._build_response(session_attributes, speechlet)

    def on_session_ended(self, session_end_request, session):
        return self._test_response("on session end")
    
